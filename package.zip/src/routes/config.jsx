import Temp from "../components/temp";
import but from "../components/login/but";
import {constantRoutes} from "./costantRoutes";

//config for our routes
export const config = [
    {
        path: constantRoutes.home,
        element: <Temp content={"home"} />,
    },
    {
        path: constantRoutes.login,
        element: <but />,
    },
    {
        path: constantRoutes.signup,
        element: <but />,
    }
];