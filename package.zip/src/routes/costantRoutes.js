export const constantRoutes = {
    home: "/",
    login: "/login",
    signup: "/signup",
};