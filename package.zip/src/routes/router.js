import { createBrowserRouter } from "react-router-dom";
import { config } from "./config";

//creating router for switching routes
const router = createBrowserRouter(config);

export default router;