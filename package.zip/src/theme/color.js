export const color = {
    primary: "#3498db",
    secondary: "#2980b9",
    white: "white",
    background_low: "f9fafb",
    text_dark: "#2c3e50",
    text_light: "#7f8c8d",
    dark_primary: "#298069",
    dark_secondary: "#16a085",
    light_grey: "#cccccc"
}